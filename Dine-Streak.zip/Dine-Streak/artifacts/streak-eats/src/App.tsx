import { useEffect, useMemo, useState } from 'react';
import {
  ArrowUpRight,
  BarChart3,
  BadgeCheck,
  Check,
  ChevronRight,
  CircleCheck,
  Compass,
  Flame,
  Gift,
  History,
  Home as HomeIcon,
  Info,
  MapPin,
  Navigation,
  Plus,
  QrCode,
  ReceiptText,
  Search,
  SlidersHorizontal,
  Sparkles,
  Star,
  Store,
  Trophy,
  Users,
  UserRound,
  Utensils,
  WalletCards,
  X,
} from 'lucide-react';
import { type ComponentType, type FormEvent, type ReactNode } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

type View = 'home' | 'discover' | 'streak' | 'visits' | 'profile' | 'owner';
type Restaurant = {
  id: string;
  name: string;
  cuisine: string;
  area: string;
  price: string;
  rating: string;
  dailyMembers: number;
  visits: number;
  distance: string;
  wait: string;
  color: string;
  accent: string;
  initials: string;
  description: string;
  special: string;
  tags: string[];
};
type Visit = {
  id: number;
  restaurant: string;
  date: string;
  amount: string;
  stamp: string;
  color: string;
};
type OwnerVisit = {
  id: number;
  customer: string;
  initials: string;
  restaurant: string;
  date: string;
  amount: string;
  streak: number;
  color: string;
};

const restaurants: Restaurant[] = [
  {
    id: 'rasa-room',
    name: 'Rasa Room',
    cuisine: 'South Indian',
    area: 'Koramangala 5th Block',
    price: '₹180–320',
    rating: '4.8',
    dailyMembers: 86,
    visits: 128,
    distance: '0.4 km',
    wait: '15 min',
    color: '#e9b949',
    accent: '#f6d889',
    initials: 'RR',
    description: 'Bright plates, quick service, and a dosa crisp enough to make a bad day better.',
    special: '15% off after 10 visits',
    tags: ['Student favourite', 'Fast tables'],
  },
  {
    id: 'miso-mill',
    name: 'Miso Mill',
    cuisine: 'Japanese comfort',
    area: 'HSR Layout',
    price: '₹220–420',
    rating: '4.7',
    dailyMembers: 61,
    visits: 94,
    distance: '0.8 km',
    wait: '20 min',
    color: '#d77c66',
    accent: '#f0b29f',
    initials: 'MM',
    description: 'A tiny noodle bar with generous bowls, soft light, and playlists worth staying for.',
    special: 'Free topping on your 7th visit',
    tags: ['Late lunch', 'Cosy'],
  },
  {
    id: 'counter-17',
    name: 'Counter 17',
    cuisine: 'Burgers & fries',
    area: 'Indiranagar',
    price: '₹190–350',
    rating: '4.6',
    dailyMembers: 48,
    visits: 76,
    distance: '1.2 km',
    wait: '10 min',
    color: '#5a856e',
    accent: '#a8c5a5',
    initials: '17',
    description: 'Messy, no-nonsense burgers made for the walk home after a long studio day.',
    special: '₹100 off your 5th check-in',
    tags: ['Open late', 'Takeaway'],
  },
  {
    id: 'little-saffron',
    name: 'Little Saffron',
    cuisine: 'North Indian',
    area: 'Ejipura',
    price: '₹150–280',
    rating: '4.5',
    dailyMembers: 37,
    visits: 61,
    distance: '1.5 km',
    wait: '12 min',
    color: '#b96654',
    accent: '#e4aa85',
    initials: 'LS',
    description: 'The kind of neighbourhood kitchen that remembers your order by the third visit.',
    special: '10% off every Wednesday',
    tags: ['Under ₹250', 'Neighbourhood gem'],
  },
  {
    id: 'paper-lantern',
    name: 'Paper Lantern',
    cuisine: 'Pan-Asian',
    area: 'BTM Stage 2',
    price: '₹240–480',
    rating: '4.4',
    dailyMembers: 29,
    visits: 43,
    distance: '2.1 km',
    wait: '25 min',
    color: '#6b7897',
    accent: '#b3c1db',
    initials: 'PL',
    description: 'Crisp vegetables, smoky noodles, and enough corner seats to open your laptop.',
    special: 'Iced tea on your 4th visit',
    tags: ['Study friendly', 'Vegetarian'],
  },
];

const startingVisits: Visit[] = [
  { id: 1, restaurant: 'Rasa Room', date: 'Today, 1:12 pm', amount: '₹240', stamp: 'Dosa + filter coffee', color: '#e9b949' },
  { id: 2, restaurant: 'Miso Mill', date: 'Yesterday, 8:04 pm', amount: '₹380', stamp: 'Spicy miso ramen', color: '#d77c66' },
  { id: 3, restaurant: 'Rasa Room', date: 'Mon, 12:48 pm', amount: '₹210', stamp: 'Mini meals thali', color: '#e9b949' },
  { id: 4, restaurant: 'Counter 17', date: 'Sun, 9:21 pm', amount: '₹295', stamp: 'Smash burger + fries', color: '#5a856e' },
  { id: 5, restaurant: 'Little Saffron', date: 'Sat, 2:02 pm', amount: '₹175', stamp: 'Rajma chawal', color: '#b96654' },
];

const startingOwnerVisits: OwnerVisit[] = [
  { id: 101, customer: 'Arjun Kulkarni', initials: 'AK', restaurant: 'Rasa Room', date: 'Today, 1:12 pm', amount: '₹240', streak: 6, color: '#e9b949' },
  { id: 102, customer: 'Meera Shah', initials: 'MS', restaurant: 'Rasa Room', date: 'Today, 12:48 pm', amount: '₹310', streak: 12, color: '#d77c66' },
  { id: 103, customer: 'Kabir Rao', initials: 'KR', restaurant: 'Rasa Room', date: 'Today, 12:22 pm', amount: '₹190', streak: 3, color: '#5a856e' },
  { id: 104, customer: 'Nisha Menon', initials: 'NM', restaurant: 'Rasa Room', date: 'Yesterday, 8:06 pm', amount: '₹265', streak: 9, color: '#b96654' },
  { id: 105, customer: 'Rohan Das', initials: 'RD', restaurant: 'Rasa Room', date: 'Yesterday, 7:44 pm', amount: '₹220', streak: 2, color: '#6b7897' },
];

const navItems: Array<{ id: View; label: string; icon: ComponentType<{ className?: string }> }> = [
  { id: 'home', label: 'Today', icon: HomeIcon },
  { id: 'discover', label: 'Find food', icon: Compass },
  { id: 'streak', label: 'My streak', icon: Flame },
  { id: 'visits', label: 'Visits', icon: History },
];

function Logo() {
  return (
    <div className="flex items-center gap-2.5" data-testid="brand-streak-eats">
      <div className="relative flex h-9 w-9 rotate-[-6deg] items-center justify-center rounded-[12px] bg-primary text-primary-foreground shadow-[3px_3px_0_hsl(258_29%_18%)]">
        <Flame className="h-5 w-5 fill-current" strokeWidth={2.5} />
        <span className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-secondary" />
      </div>
      <div className="leading-none">
        <div className="display-font text-[17px] font-bold tracking-[-.04em]">streak eats</div>
        <div className="mono-font mt-1 text-[8px] uppercase tracking-[.18em] text-muted-foreground">good food, on repeat</div>
      </div>
    </div>
  );
}

function Avatar({ small = false }: { small?: boolean }) {
  return (
    <div className={`${small ? 'h-8 w-8 text-[11px]' : 'h-10 w-10 text-sm'} flex items-center justify-center rounded-full border-2 border-card bg-secondary font-bold text-foreground shadow-[2px_2px_0_hsl(258_29%_18%)]`} data-testid="img-avatar-arjun">
      AK
    </div>
  );
}

function AppSidebar({ active, onNavigate }: { active: View; onNavigate: (view: View) => void }) {
  return (
    <aside className="hidden w-[228px] shrink-0 flex-col bg-sidebar px-4 py-5 text-sidebar-foreground md:flex">
      <div className="px-3"><Logo /></div>
      <div className="mt-12 px-3">
        <p className="mono-font text-[10px] uppercase tracking-[.2em] text-sidebar-foreground/45">Your canteen, but better</p>
      </div>
      <nav className="mt-4 space-y-1" aria-label="Main navigation">
        {navItems.map((item) => {
          const Icon = item.icon;
          const selected = active === item.id;
          return (
            <button
              key={item.id}
              type="button"
              data-testid={`nav-${item.id}`}
              onClick={() => onNavigate(item.id)}
              className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-semibold transition-all ${selected ? 'bg-sidebar-accent text-sidebar-accent-foreground shadow-[inset_3px_0_0_hsl(var(--primary))]' : 'text-sidebar-foreground/60 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground'}`}
            >
              <Icon className={`h-[18px] w-[18px] ${selected ? 'text-sidebar-primary' : ''}`} />
              {item.label}
              {item.id === 'streak' && <span className="mono-font ml-auto text-[10px] text-sidebar-primary">06</span>}
            </button>
          );
        })}
      </nav>
      <div className="mt-auto rounded-2xl border border-sidebar-border bg-sidebar-accent p-4">
        <div className="mb-3 flex items-center justify-between">
          <span className="mono-font text-[10px] uppercase tracking-[.16em] text-sidebar-foreground/50">Next unlock</span>
          <Gift className="h-4 w-4 text-sidebar-primary" />
        </div>
        <div className="display-font text-xl font-bold">15% off</div>
        <p className="mt-1 text-xs leading-relaxed text-sidebar-foreground/60">Keep showing up at any Streak Eats spot.</p>
        <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-sidebar-border">
          <div className="h-full w-[60%] rounded-full bg-sidebar-primary" />
        </div>
        <div className="mono-font mt-2 flex justify-between text-[10px] text-sidebar-foreground/50"><span>6 of 10 visits</span><span>4 to go</span></div>
      </div>
      <button type="button" data-testid="nav-owner" onClick={() => onNavigate('owner')} className={`mt-4 flex items-center gap-3 rounded-xl border px-3 py-3 text-left text-sm font-semibold transition-colors ${active === 'owner' ? 'border-sidebar-primary/40 bg-sidebar-accent text-sidebar-foreground' : 'border-sidebar-border text-sidebar-foreground/65 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground'}`}>
        <Store className={`h-[18px] w-[18px] ${active === 'owner' ? 'text-sidebar-primary' : ''}`} />
        <span className="flex-1">Owner view</span>
        <ChevronRight className="h-4 w-4 text-sidebar-foreground/40" />
      </button>
      <button type="button" data-testid="nav-profile" onClick={() => onNavigate('profile')} className="mt-4 flex items-center gap-3 rounded-xl px-3 py-3 text-left hover:bg-sidebar-accent">
        <Avatar small />
        <div className="min-w-0"><div className="truncate text-sm font-semibold">Arjun Kulkarni</div><div className="text-xs text-sidebar-foreground/50">Bengaluru · Student</div></div>
        <ChevronRight className="ml-auto h-4 w-4 text-sidebar-foreground/40" />
      </button>
    </aside>
  );
}

function MobileNav({ active, onNavigate }: { active: View; onNavigate: (view: View) => void }) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 flex border-t border-border bg-card/95 px-2 pb-[env(safe-area-inset-bottom)] pt-2 backdrop-blur md:hidden" aria-label="Mobile navigation">
      {navItems.map((item) => {
        const Icon = item.icon;
        const selected = active === item.id;
        return (
          <button key={item.id} type="button" data-testid={`mobile-nav-${item.id}`} onClick={() => onNavigate(item.id)} className={`flex flex-1 flex-col items-center gap-1 py-1.5 text-[10px] font-semibold ${selected ? 'text-foreground' : 'text-muted-foreground'}`}>
            <span className={`flex h-7 w-10 items-center justify-center rounded-full ${selected ? 'bg-primary' : ''}`}><Icon className="h-[17px] w-[17px]" /></span>
            {item.label}
          </button>
        );
      })}
      <button type="button" data-testid="mobile-nav-profile" onClick={() => onNavigate('profile')} className={`flex flex-1 flex-col items-center gap-1 py-1.5 text-[10px] font-semibold ${active === 'profile' ? 'text-foreground' : 'text-muted-foreground'}`}>
        <span className={`flex h-7 w-10 items-center justify-center rounded-full ${active === 'profile' ? 'bg-primary' : ''}`}><UserRound className="h-[17px] w-[17px]" /></span>
        Profile
      </button>
    </nav>
  );
}

function Topbar({ active, onNavigate }: { active: View; onNavigate: (view: View) => void }) {
  const labels: Record<View, string> = { home: 'Today', discover: 'Find food', streak: 'My streak', visits: 'Visits', profile: 'Profile', owner: 'Owner view' };
  return (
    <header className="flex h-[74px] items-center justify-between border-b border-border px-5 sm:px-8 lg:px-10">
      <div className="flex items-center gap-3 md:hidden"><Logo /></div>
      <div className="hidden items-center gap-2 text-sm text-muted-foreground md:flex"><span className="font-semibold text-foreground">{labels[active]}</span><span>/</span><span>Monday, 14 October</span></div>
      <div className="ml-auto flex items-center gap-3">
        <button type="button" data-testid="button-location" onClick={() => onNavigate('discover')} className="hidden items-center gap-1.5 rounded-full border border-border px-3 py-2 text-xs font-semibold text-muted-foreground transition-colors hover:bg-muted sm:flex"><MapPin className="h-3.5 w-3.5 text-accent" /> Koramangala <ChevronRight className="h-3 w-3" /></button>
        <button type="button" data-testid="button-owner-view" onClick={() => onNavigate(active === 'owner' ? 'home' : 'owner')} className={`flex items-center gap-1.5 rounded-full border px-2.5 py-2 text-[11px] font-semibold transition-colors sm:px-3 sm:text-xs ${active === 'owner' ? 'border-primary bg-primary/15 text-foreground' : 'border-border text-muted-foreground hover:bg-muted'}`}><Store className="h-3.5 w-3.5 text-accent" /> {active === 'owner' ? 'Student view' : 'Owner view'}</button>
        <button type="button" data-testid="button-profile-top" onClick={() => onNavigate('profile')} className="flex items-center gap-2 rounded-full pl-2 hover:bg-muted"><Avatar small /><span className="hidden text-sm font-semibold sm:block">Arjun</span></button>
      </div>
    </header>
  );
}

function StatPill({ icon: Icon, value, label, tone = 'primary' }: { icon: typeof Flame; value: string; label: string; tone?: 'primary' | 'accent' | 'secondary' }) {
  return <div className="flex items-center gap-2.5 rounded-xl border border-border bg-card px-3 py-2.5"><div className={`flex h-8 w-8 items-center justify-center rounded-lg ${tone === 'primary' ? 'bg-primary/25 text-foreground' : tone === 'accent' ? 'bg-accent/15 text-accent' : 'bg-secondary/20 text-secondary-foreground'}`}><Icon className="h-4 w-4" /></div><div><div className="display-font text-base font-bold leading-none">{value}</div><div className="mt-1 text-[10px] text-muted-foreground">{label}</div></div></div>;
}

function RestaurantMark({ restaurant, className = '' }: { restaurant: Restaurant; className?: string }) {
  return (
    <div className={`relative overflow-hidden ${className}`} style={{ background: `linear-gradient(135deg, ${restaurant.color}, ${restaurant.accent})` }}>
      <div className="absolute -right-5 -top-8 h-28 w-28 rounded-full border-[16px] border-foreground/10" />
      <div className="absolute -bottom-10 -left-6 h-28 w-28 rounded-full border-[12px] border-card/20" />
      <div className="absolute bottom-3 left-4 flex h-10 w-10 items-center justify-center rounded-xl border border-foreground/10 bg-card/70 display-font text-sm font-bold text-foreground/80 backdrop-blur">{restaurant.initials}</div>
      <Utensils className="absolute right-4 top-4 h-5 w-5 rotate-12 text-foreground/35" />
    </div>
  );
}

function RestaurantCard({ restaurant, onSelect }: { restaurant: Restaurant; onSelect: (restaurant: Restaurant) => void }) {
  return (
    <button type="button" data-testid={`card-restaurant-${restaurant.id}`} onClick={() => onSelect(restaurant)} className="pressable group w-full overflow-hidden rounded-2xl border border-border bg-card text-left shadow-sm">
      <RestaurantMark restaurant={restaurant} className="h-32 w-full" />
      <div className="p-4">
        <div className="flex items-start justify-between gap-3"><div><h3 className="display-font text-lg font-bold tracking-[-.03em]">{restaurant.name}</h3><p className="mt-1 text-xs text-muted-foreground">{restaurant.cuisine} · {restaurant.area}</p></div><span className="flex items-center gap-1 text-xs font-bold"><Star className="h-3.5 w-3.5 fill-primary text-primary" /> {restaurant.rating}</span></div>
        <div className="mt-4 flex items-center gap-2 text-[11px] text-muted-foreground"><span>{restaurant.price}</span><span className="text-border">•</span><span>{restaurant.distance}</span><span className="text-border">•</span><span>{restaurant.wait} wait</span></div>
        <div className="mt-3 flex items-center justify-between"><span className="rounded-full bg-primary/20 px-2.5 py-1 text-[10px] font-bold text-foreground">{restaurant.special}</span><ArrowUpRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" /></div>
      </div>
    </button>
  );
}

function RestaurantDetail({ restaurant, onClose }: { restaurant: Restaurant; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-foreground/35 p-0 backdrop-blur-[2px] sm:items-center sm:p-4" role="dialog" aria-modal="true" aria-label={`${restaurant.name} details`}>
      <div className="page-enter max-h-[90dvh] w-full max-w-lg overflow-y-auto rounded-t-[28px] border border-border bg-card shadow-2xl sm:rounded-[28px]">
        <div className="relative"><RestaurantMark restaurant={restaurant} className="h-48 w-full" /><button type="button" data-testid="button-close-details" onClick={onClose} className="absolute right-4 top-4 rounded-full bg-card/80 p-2 backdrop-blur hover:bg-card"><X className="h-5 w-5" /></button></div>
        <div className="p-6"><div className="flex items-start justify-between gap-4"><div><p className="text-xs font-semibold text-muted-foreground">{restaurant.cuisine} · {restaurant.area}</p><h2 className="display-font mt-1 text-3xl font-bold tracking-[-.05em]">{restaurant.name}</h2></div><div className="text-right"><div className="flex items-center gap-1 text-sm font-bold"><Star className="h-4 w-4 fill-primary text-primary" /> {restaurant.rating}</div><div className="mt-1 text-[10px] text-muted-foreground">{restaurant.visits} student visits</div></div></div>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{restaurant.description}</p>
           <div className="mt-5 grid grid-cols-3 gap-2">
             <div className="rounded-2xl bg-muted p-3"><Users className="h-4 w-4 text-accent" /><div className="display-font mt-3 text-xl font-bold">{restaurant.dailyMembers}</div><div className="mt-1 text-[10px] leading-tight text-muted-foreground">members visiting daily</div></div>
             <div className="rounded-2xl bg-muted p-3"><Star className="h-4 w-4 fill-primary text-primary" /><div className="display-font mt-3 text-xl font-bold">{restaurant.rating}</div><div className="mt-1 text-[10px] leading-tight text-muted-foreground">student rating</div></div>
             <div className="rounded-2xl bg-muted p-3"><Gift className="h-4 w-4 text-secondary" /><div className="display-font mt-3 text-sm font-bold leading-tight">{restaurant.special}</div><div className="mt-1 text-[10px] leading-tight text-muted-foreground">streak offer</div></div>
           </div>
           <div className="mt-5 flex items-center gap-3 rounded-2xl border border-primary/40 bg-primary/10 p-3.5"><Gift className="h-5 w-5 text-accent" /><div><div className="text-xs font-bold">Reward for showing up again</div><div className="mt-0.5 text-[11px] text-muted-foreground">{restaurant.special} · funded by the owner</div></div></div>
          <div className="mt-4 flex items-center justify-center gap-1.5 text-[11px] text-muted-foreground"><Navigation className="h-3.5 w-3.5" /> {restaurant.distance} away · Open until 11:00 pm</div>
        </div>
      </div>
    </div>
  );
}

function HomeView({ onNavigate, onSelect, visitCount }: { onNavigate: (view: View) => void; onSelect: (restaurant: Restaurant) => void; visitCount: number }) {
  const featured = restaurants.slice(0, 3);
  return (
    <div className="page-enter mx-auto max-w-[1240px] px-5 py-7 sm:px-8 lg:px-10 lg:py-10">
      <section className="relative overflow-hidden rounded-[26px] bg-sidebar px-6 py-7 text-sidebar-foreground sm:px-9 sm:py-9 lg:px-12 lg:py-11">
        <div className="absolute -right-16 -top-20 h-64 w-64 rounded-full border-[34px] border-primary/15" /><div className="absolute bottom-[-80px] right-[22%] h-52 w-52 rounded-full border-[26px] border-secondary/10" />
        <div className="relative max-w-[640px]"><p className="mono-font text-[10px] uppercase tracking-[.22em] text-sidebar-primary">Monday, 14 October · Koramangala</p><h1 className="display-font mt-4 max-w-[560px] text-[clamp(2.5rem,6vw,4.5rem)] font-bold leading-[.94] tracking-[-.07em]">What’s worth showing up for today?</h1><p className="mt-5 max-w-md text-sm leading-relaxed text-sidebar-foreground/60">Good food is better when it becomes a habit. Find your next table, keep your streak warm.</p>
          <div className="mt-7 flex flex-wrap gap-3"><button type="button" data-testid="button-find-food" onClick={() => onNavigate('discover')} className="flex items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground shadow-[3px_3px_0_hsl(258_29%_18%)]">Find food <ArrowUpRight className="h-4 w-4" /></button><button type="button" data-testid="button-open-streak" onClick={() => onNavigate('streak')} className="rounded-xl border border-sidebar-foreground/20 px-4 py-3 text-sm font-semibold text-sidebar-foreground/80 hover:bg-sidebar-accent">See my streak</button></div>
        </div>
        <div className="relative mt-8 flex items-end gap-2 sm:absolute sm:bottom-8 sm:right-10 sm:mt-0"><div className="rounded-2xl bg-primary px-4 py-3 text-foreground shadow-[4px_4px_0_hsl(258_29%_18%)]"><div className="mono-font text-[9px] uppercase tracking-[.16em]">Current streak</div><div className="display-font mt-1 text-4xl font-bold">{visitCount}<span className="ml-1 text-xl">days</span></div></div><div className="mb-1 rounded-2xl border border-sidebar-foreground/15 bg-sidebar-accent px-3 py-3"><Flame className="h-5 w-5 text-sidebar-primary" /><div className="mono-font mt-2 text-[9px] text-sidebar-foreground/50">on fire</div></div></div>
      </section>
      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4"><StatPill icon={Flame} value={`${visitCount} days`} label="current streak" /><StatPill icon={Gift} value="15%" label="next reward" tone="secondary" /><StatPill icon={WalletCards} value="₹1,240" label="spent locally" tone="accent" /><StatPill icon={Store} value="4" label="places visited" tone="secondary" /></div>
      <section className="mt-10"><div className="flex items-end justify-between"><div><p className="mono-font text-[10px] uppercase tracking-[.2em] text-accent">Made for today</p><h2 className="display-font mt-1 text-2xl font-bold tracking-[-.04em]">Nearby, hungry, sorted.</h2></div><button type="button" data-testid="button-see-all-restaurants" onClick={() => onNavigate('discover')} className="flex items-center gap-1 text-xs font-bold text-muted-foreground hover:text-foreground">See all <ChevronRight className="h-4 w-4" /></button></div>
        <div className="mt-5 grid gap-4 md:grid-cols-3">{featured.map((restaurant, index) => <div key={restaurant.id} className={`lift-in stagger-${index + 1}`}><RestaurantCard restaurant={restaurant} onSelect={onSelect} /></div>)}</div>
      </section>
       <section className="mt-10 grid gap-5 lg:grid-cols-[1.25fr_.75fr]"><div className="rounded-2xl border border-border bg-card p-5 shadow-sm sm:p-6"><div className="flex items-start justify-between"><div><p className="mono-font text-[10px] uppercase tracking-[.2em] text-accent">Your next unlock</p><h3 className="display-font mt-1 text-2xl font-bold tracking-[-.04em]">The regulars club</h3></div><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/25"><Trophy className="h-5 w-5" /></div></div><p className="mt-3 max-w-lg text-sm text-muted-foreground">10 visits unlocks 15% off at participating restaurants. The discount is funded by the owner — your repeat visits are the thank you.</p><div className="mt-6 flex items-end justify-between"><div className="display-font text-3xl font-bold">6 <span className="text-lg font-medium text-muted-foreground">/ 10</span></div><span className="mono-font text-[10px] text-muted-foreground">4 more check-ins</span></div><div className="mt-2 h-3 overflow-hidden rounded-full bg-muted"><div className="progress-fill h-full w-[60%] rounded-full bg-primary" /></div></div>
        <div className="rounded-2xl bg-secondary p-5 text-secondary-foreground shadow-sm sm:p-6"><div className="flex items-center justify-between"><p className="mono-font text-[10px] uppercase tracking-[.2em]">Last visit</p><History className="h-5 w-5" /></div><h3 className="display-font mt-8 text-2xl font-bold tracking-[-.04em]">Rasa Room</h3><p className="mt-1 text-sm opacity-70">Today · Dosa + filter coffee</p><div className="mt-6 flex items-center justify-between border-t border-secondary-foreground/15 pt-4 text-xs"><span>₹240 · Visit verified</span><CircleCheck className="h-4 w-4" /></div></div></section>
    </div>
  );
}

function DiscoverView({ onSelect }: { onSelect: (restaurant: Restaurant) => void }) {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('All');
  const filters = ['All', 'Under ₹250', 'Open late', 'Study friendly'];
  const filtered = useMemo(() => restaurants.filter((restaurant) => {
    const matchQuery = `${restaurant.name} ${restaurant.cuisine} ${restaurant.area}`.toLowerCase().includes(query.toLowerCase());
    const matchFilter = filter === 'All' || (filter === 'Under ₹250' ? restaurant.price.includes('150') || restaurant.price.includes('180') || restaurant.price.includes('190') : restaurant.tags.includes(filter));
    return matchQuery && matchFilter;
  }), [filter, query]);
  return <div className="page-enter mx-auto max-w-[1240px] px-5 py-7 sm:px-8 lg:px-10 lg:py-10"><div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="mono-font text-[10px] uppercase tracking-[.2em] text-accent">Your neighbourhood menu</p><h1 className="display-font mt-1 text-4xl font-bold tracking-[-.06em]">Find your next regular.</h1><p className="mt-2 text-sm text-muted-foreground">Good places nearby, with a reason to come back.</p></div><div className="flex items-center gap-2 text-xs text-muted-foreground"><Navigation className="h-4 w-4 text-accent" /> Within 2.5 km</div></div>
    <div className="mt-7 flex flex-col gap-3 sm:flex-row"><label className="relative flex-1"><Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><input type="search" data-testid="input-search-restaurants" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search restaurants, cuisines, areas..." className="h-12 w-full rounded-xl border border-border bg-card pl-11 pr-4 text-sm outline-none transition-shadow placeholder:text-muted-foreground/70 focus:border-primary focus:ring-4 focus:ring-primary/15" /></label><button type="button" data-testid="button-filter" onClick={() => setFilter(filter === 'All' ? 'Open late' : 'All')} className="flex h-12 items-center justify-center gap-2 rounded-xl border border-border bg-card px-4 text-sm font-semibold hover:bg-muted"><SlidersHorizontal className="h-4 w-4" /> Filters {filter !== 'All' && <span className="h-2 w-2 rounded-full bg-primary" />}</button></div>
    <div className="scrollbar-none mt-4 flex gap-2 overflow-x-auto pb-1">{filters.map((item) => <button key={item} type="button" data-testid={`filter-${item.toLowerCase().replaceAll(' ', '-')}`} onClick={() => setFilter(item)} className={`whitespace-nowrap rounded-full px-3.5 py-2 text-xs font-bold transition-colors ${filter === item ? 'bg-foreground text-background' : 'border border-border bg-card text-muted-foreground hover:bg-muted'}`}>{item}</button>)}</div>
    {filtered.length > 0 ? <div className="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{filtered.map((restaurant, index) => <div key={restaurant.id} className={`lift-in stagger-${(index % 3) + 1}`}><RestaurantCard restaurant={restaurant} onSelect={onSelect} /></div>)}</div> : <div className="mt-8 rounded-2xl border border-dashed border-border bg-card p-12 text-center"><Search className="mx-auto h-8 w-8 text-muted-foreground/50" /><h2 className="display-font mt-4 text-2xl font-bold">No tables found</h2><p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">Try a different cuisine, area, or clear your filters. Your next favourite is probably close.</p><button type="button" data-testid="button-clear-search" onClick={() => { setQuery(''); setFilter('All'); }} className="mt-5 rounded-xl bg-primary px-4 py-2.5 text-xs font-bold">Clear search</button></div>}
  </div>;
}

function StreakView({ visitCount, onNavigate }: { visitCount: number; onNavigate: (view: View) => void }) {
  const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
  return <div className="page-enter mx-auto max-w-[1000px] px-5 py-7 sm:px-8 lg:px-10 lg:py-10"><div className="rounded-[26px] bg-primary p-6 sm:p-9"><div className="flex flex-col justify-between gap-8 sm:flex-row sm:items-end"><div><p className="mono-font text-[10px] uppercase tracking-[.2em] text-foreground/60">Momentum is a meal</p><h1 className="display-font mt-2 text-5xl font-bold tracking-[-.08em] sm:text-7xl">{visitCount} <span className="text-3xl tracking-[-.04em] sm:text-4xl">days in</span></h1><p className="mt-3 max-w-sm text-sm text-foreground/70">Six visits, zero skipped days. You’re building a very good habit.</p></div><div className="flex h-20 w-20 rotate-3 items-center justify-center rounded-[22px] bg-card text-foreground shadow-[4px_4px_0_hsl(258_29%_18%)]"><Flame className="h-10 w-10 fill-secondary text-secondary" /></div></div><div className="mt-9 grid grid-cols-7 gap-2 sm:gap-3">{days.map((day, index) => <div key={`${day}-${index}`} className="text-center"><div className="mono-font mb-2 text-[10px] text-foreground/55">{day}</div><div className={`mx-auto flex aspect-square w-full max-w-[68px] items-center justify-center rounded-xl border-2 ${index < 6 ? 'border-foreground/20 bg-foreground text-primary' : 'border-foreground/25 text-foreground/40'}`}>{index < 6 ? <Check className="h-5 w-5" /> : <Plus className="h-4 w-4" />}</div></div>)}</div></div>
    <div className="mt-6 grid gap-5 lg:grid-cols-[1.1fr_.9fr]"><div className="rounded-2xl border border-border bg-card p-5 sm:p-7"><div className="flex items-center justify-between"><div><p className="mono-font text-[10px] uppercase tracking-[.2em] text-accent">Reward runway</p><h2 className="display-font mt-1 text-2xl font-bold tracking-[-.04em]">Four more for 15% off</h2></div><Gift className="h-6 w-6 text-secondary" /></div><div className="mt-7 flex items-center gap-2">{Array.from({ length: 10 }, (_, index) => <div key={index} className={`flex h-8 flex-1 items-center justify-center rounded-lg text-[10px] font-bold ${index < 6 ? 'bg-primary text-foreground' : 'bg-muted text-muted-foreground'}`}>{index + 1}</div>)}</div><div className="mt-4 flex justify-between text-xs text-muted-foreground"><span>6 visits logged</span><span>Next reward at 10</span></div><button type="button" data-testid="button-discover-streak" onClick={() => onNavigate('discover')} className="mt-7 flex items-center gap-2 text-xs font-bold text-accent">Make today count <ArrowUpRight className="h-4 w-4" /></button></div><div className="rounded-2xl border border-border bg-secondary p-5 text-secondary-foreground sm:p-7"><Sparkles className="h-6 w-6" /><h2 className="display-font mt-8 text-2xl font-bold tracking-[-.04em]">Why streaks?</h2><p className="mt-3 text-sm leading-relaxed opacity-75">Every check-in is a small vote for the neighbourhood you want to live in. Restaurants get regulars. You get better prices.</p><div className="mt-7 flex items-center gap-2 border-t border-secondary-foreground/15 pt-4 text-xs font-bold"><Store className="h-4 w-4" /> 4 local spots in your orbit</div></div></div>
  </div>;
}

function VisitsView({ visits, onNavigate }: { visits: Visit[]; onNavigate: (view: View) => void }) {
  return <div className="page-enter mx-auto max-w-[960px] px-5 py-7 sm:px-8 lg:px-10 lg:py-10"><div className="flex items-end justify-between"><div><p className="mono-font text-[10px] uppercase tracking-[.2em] text-accent">Your paper trail</p><h1 className="display-font mt-1 text-4xl font-bold tracking-[-.06em]">Visits</h1><p className="mt-2 text-sm text-muted-foreground">Every plate that kept your streak alive.</p></div><div className="hidden rounded-xl bg-card px-4 py-3 text-right shadow-sm sm:block"><div className="display-font text-2xl font-bold">₹1,240</div><div className="text-[10px] text-muted-foreground">spent locally</div></div></div><div className="mt-7 rounded-2xl border border-border bg-card shadow-sm">{visits.length ? visits.map((visit, index) => <div key={visit.id} className={`flex items-center gap-3 border-b border-border p-4 last:border-b-0 sm:gap-5 sm:p-5 ${index === 0 ? 'bg-primary/5' : ''}`}><div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-xs font-bold" style={{ backgroundColor: visit.color }}>{visit.restaurant.split(' ').map((word) => word[0]).join('')}</div><div className="min-w-0 flex-1"><div className="flex items-center gap-2"><h3 className="truncate text-sm font-bold">{visit.restaurant}</h3>{index === 0 && <span className="rounded-full bg-accent/15 px-2 py-0.5 text-[9px] font-bold text-accent">Latest</span>}</div><p className="mt-1 truncate text-xs text-muted-foreground">{visit.stamp}</p></div><div className="hidden text-right sm:block"><div className="text-xs font-semibold">{visit.date}</div><div className="mt-1 flex items-center justify-end gap-1 text-[10px] text-accent"><CircleCheck className="h-3 w-3" /> Visit verified</div></div><div className="text-right"><div className="text-sm font-bold">{visit.amount}</div><div className="mt-1 text-[10px] text-muted-foreground sm:hidden">{visit.date.split(',')[0]}</div></div></div>) : <div className="p-12 text-center"><ReceiptText className="mx-auto h-9 w-9 text-muted-foreground/50" /><h2 className="display-font mt-4 text-2xl font-bold">No visits yet</h2><p className="mt-2 text-sm text-muted-foreground">Your first table is waiting.</p><button type="button" data-testid="button-find-first-visit" onClick={() => onNavigate('discover')} className="mt-5 rounded-xl bg-primary px-4 py-2.5 text-xs font-bold">Find a restaurant</button></div>}</div></div>;
}

function ProfileView({ onNavigate, rewardClaimed, onClaimReward }: { onNavigate: (view: View) => void; rewardClaimed: boolean; onClaimReward: () => void }) {
  return <div className="page-enter mx-auto max-w-[960px] px-5 py-7 sm:px-8 lg:px-10 lg:py-10"><div className="rounded-[26px] bg-sidebar p-6 text-sidebar-foreground sm:p-9"><div className="flex flex-col gap-5 sm:flex-row sm:items-center"><Avatar /><div><p className="mono-font text-[10px] uppercase tracking-[.2em] text-sidebar-foreground/50">Member since September 2024</p><h1 className="display-font mt-1 text-3xl font-bold tracking-[-.05em]">Arjun Kulkarni</h1><p className="mt-1 text-sm text-sidebar-foreground/60">Student · Bengaluru · 6 day streak</p></div><button type="button" data-testid="button-edit-profile" onClick={() => window.alert('Profile editing is coming in the next build.')} className="sm:ml-auto rounded-xl border border-sidebar-foreground/20 px-4 py-2.5 text-xs font-bold hover:bg-sidebar-accent">Edit profile</button></div></div>
    <div className="mt-6 grid gap-4 sm:grid-cols-3"><div className="rounded-2xl border border-border bg-card p-5"><div className="mono-font text-[10px] uppercase tracking-[.18em] text-muted-foreground">Total visits</div><div className="display-font mt-2 text-3xl font-bold">18</div></div><div className="rounded-2xl border border-border bg-card p-5"><div className="mono-font text-[10px] uppercase tracking-[.18em] text-muted-foreground">Places found</div><div className="display-font mt-2 text-3xl font-bold">07</div></div><div className="rounded-2xl border border-border bg-card p-5"><div className="mono-font text-[10px] uppercase tracking-[.18em] text-muted-foreground">Saved locally</div><div className="display-font mt-2 text-3xl font-bold">₹1,240</div></div></div>
     <div className="mt-6 grid gap-5 lg:grid-cols-[1.1fr_.9fr]"><div className="rounded-2xl border border-border bg-card p-5 sm:p-7"><div className="flex items-center justify-between"><div><p className="mono-font text-[10px] uppercase tracking-[.2em] text-accent">Your rewards</p><h2 className="display-font mt-1 text-2xl font-bold tracking-[-.04em]">Earned, not gamed.</h2></div><Trophy className="h-6 w-6 text-secondary" /></div><div className={`mt-6 rounded-2xl p-4 ${rewardClaimed ? 'bg-accent/10' : 'bg-primary/15'}`}><div className="flex items-start gap-3"><div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-card"><Gift className="h-5 w-5 text-secondary" /></div><div className="flex-1"><div className="text-sm font-bold">15% off your next meal</div><p className="mt-1 text-xs text-muted-foreground">{rewardClaimed ? 'Claimed. Show this screen at a participating restaurant.' : 'Unlocks after 10 consecutive visits.'}</p></div>{rewardClaimed ? <CircleCheck className="h-5 w-5 text-accent" /> : <button type="button" data-testid="button-claim-reward" onClick={onClaimReward} className="rounded-lg bg-foreground px-3 py-2 text-[10px] font-bold text-background">Claim</button>}</div>{rewardClaimed && <button type="button" data-testid="button-redeem-reward" onClick={() => window.alert('Show this reward screen to the restaurant to redeem.')} className="mt-4 w-full rounded-xl bg-accent px-4 py-3 text-xs font-bold text-accent-foreground">Redeem at a restaurant</button>}</div></div><div className="rounded-2xl border border-border bg-card p-5 sm:p-7"><div className="flex items-center gap-2"><Info className="h-4 w-4 text-accent" /><h2 className="text-sm font-bold">How Streak Eats works</h2></div><ol className="mt-5 space-y-4">{['Find a welcoming local restaurant.', 'Pay in person and keep your visit history updated.', 'Build your streak and unlock owner-funded rewards.'].map((text, index) => <li key={text} className="flex gap-3 text-xs leading-relaxed text-muted-foreground"><span className="mono-font flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-muted text-[10px] font-bold text-foreground">{index + 1}</span>{text}</li>)}</ol><button type="button" data-testid="button-profile-find-food" onClick={() => onNavigate('discover')} className="mt-6 flex items-center gap-2 text-xs font-bold text-accent">Find somewhere new <ArrowUpRight className="h-4 w-4" /></button></div></div>
  </div>;
}

const OWNER_EMAIL = 'owner@streakeats.com';
const OWNER_PASSWORD = 'streak123';

function OwnerLogin({ onLogin }: { onLogin: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (email.trim().toLowerCase() === OWNER_EMAIL && password === OWNER_PASSWORD) {
      onLogin();
      return;
    }
    setError('That email or password does not match the owner account.');
  };

  return (
    <div className="page-enter mx-auto flex min-h-[calc(100dvh-74px)] max-w-[520px] items-center px-5 py-10 sm:px-8">
      <div className="w-full rounded-[26px] border border-border bg-card p-6 shadow-sm sm:p-9">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/25"><Store className="h-6 w-6" /></div>
        <p className="mono-font mt-7 text-[10px] uppercase tracking-[.2em] text-accent">Restaurant portal</p>
        <h1 className="display-font mt-2 text-4xl font-bold tracking-[-.06em]">Owner sign in</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">Sign in to see your daily members, repeat visits, ratings, and streak offer performance.</p>
        <form onSubmit={submit} className="mt-7 space-y-4">
          <label className="block text-xs font-bold">Email<input data-testid="input-owner-email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="owner@streakeats.com" className="mt-2 h-12 w-full rounded-xl border border-border bg-background px-4 text-sm outline-none focus:border-primary focus:ring-4 focus:ring-primary/15" required /></label>
          <label className="block text-xs font-bold">Password<input data-testid="input-owner-password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Enter your password" className="mt-2 h-12 w-full rounded-xl border border-border bg-background px-4 text-sm outline-none focus:border-primary focus:ring-4 focus:ring-primary/15" required /></label>
          {error && <p role="alert" className="rounded-xl bg-destructive/10 px-3 py-2 text-xs font-semibold text-destructive">{error}</p>}
          <button type="submit" data-testid="button-owner-login" className="w-full rounded-xl bg-primary px-4 py-3.5 text-sm font-bold text-primary-foreground shadow-[3px_3px_0_hsl(258_29%_18%)]">Open dashboard</button>
        </form>
        <div className="mt-5 rounded-xl bg-muted p-3 text-xs text-muted-foreground"><span className="font-bold text-foreground">Demo login:</span> {OWNER_EMAIL} · {OWNER_PASSWORD}</div>
      </div>
    </div>
  );
}

function OwnerVenueQr() {
  const [generation, setGeneration] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(60);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setSecondsLeft((current) => {
        if (current <= 1) {
          setGeneration((currentGeneration) => currentGeneration + 1);
          return 60;
        }
        return current - 1;
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, []);

  const token = `RASA-${String(generation).padStart(2, '0')}`;
  const value = `https://streakeats.app/check-in/rasa-room?token=${token}`;

  return (
    <div className="mt-6 flex flex-col gap-5 rounded-2xl border border-primary/30 bg-primary/10 p-5 sm:flex-row sm:items-center sm:p-6">
      <div className="flex h-36 w-36 shrink-0 items-center justify-center rounded-xl bg-card p-3 shadow-sm" aria-label="Refreshing venue QR code" data-testid="owner-venue-qr">
        <QRCodeSVG value={value} size={120} bgColor="#ffffff" fgColor="#2d243e" level="H" includeMargin />
      </div>
      <div className="flex-1">
        <p className="mono-font text-[10px] uppercase tracking-[.18em] text-accent">Live venue QR</p>
        <h2 className="display-font mt-1 text-2xl font-bold tracking-[-.04em]">Refreshes every minute.</h2>
        <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">Keep this code at the counter. A new code is generated automatically before the current one expires.</p>
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <span className="mono-font rounded-lg bg-card px-2.5 py-1.5 text-[10px] font-bold tracking-[.14em]" data-testid="owner-venue-token">{token}</span>
          <span className="flex items-center gap-1.5 text-[10px] font-semibold text-muted-foreground"><BadgeCheck className="h-3.5 w-3.5 text-accent" /> New code in {secondsLeft}s</span>
        </div>
        <div className="mt-4 h-1.5 max-w-sm overflow-hidden rounded-full bg-card/70"><div className="h-full rounded-full bg-accent transition-[width] duration-1000" style={{ width: `${(secondsLeft / 60) * 100}%` }} /></div>
      </div>
    </div>
  );
}

function OwnerView({ ownerVisits, onLogout }: { ownerVisits: OwnerVisit[]; onLogout: () => void }) {
  const venue = restaurants[0];
  const returningGuests = new Set(ownerVisits.filter((visit) => visit.streak > 1).map((visit) => visit.customer)).size;
  const activeStreaks = ownerVisits.filter((visit) => visit.streak >= 3).length;
  const verifiedToday = ownerVisits.filter((visit) => visit.date.startsWith('Today')).length;
  return (
    <div className="page-enter mx-auto max-w-[1180px] px-5 py-7 sm:px-8 lg:px-10 lg:py-10">
      <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div><p className="mono-font text-[10px] uppercase tracking-[.2em] text-accent">Rasa Room · owner dashboard</p><h1 className="display-font mt-1 text-4xl font-bold tracking-[-.06em]">Your regulars, at a glance.</h1><p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">A simple view of who visits, how they rate you, and what your streak offer is driving.</p></div>
        <div className="flex items-center gap-2"><span className="flex items-center gap-2 rounded-xl border border-accent/30 bg-accent/10 px-3 py-2 text-xs font-bold"><BadgeCheck className="h-4 w-4 text-accent" /> Live dashboard</span><button type="button" data-testid="button-owner-logout" onClick={onLogout} className="rounded-xl border border-border px-3 py-2 text-xs font-bold text-muted-foreground hover:bg-muted">Log out</button></div>
      </div>

      <div className="mt-7 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatPill icon={Users} value={`${venue.dailyMembers}`} label="members visiting daily" tone="primary" />
        <StatPill icon={Star} value={venue.rating} label="student rating" tone="accent" />
        <StatPill icon={Gift} value="15%" label="streak offer" tone="secondary" />
        <StatPill icon={Flame} value={`${activeStreaks}`} label="active streaks" tone="secondary" />
      </div>

      <OwnerVenueQr />

      <div className="mt-6 grid gap-5 lg:grid-cols-[.9fr_1.1fr]">
        <div className="rounded-2xl bg-sidebar p-5 text-sidebar-foreground sm:p-7">
          <div className="flex items-start justify-between"><div><p className="mono-font text-[10px] uppercase tracking-[.18em] text-sidebar-foreground/50">This week</p><h2 className="display-font mt-2 text-2xl font-bold tracking-[-.04em]">Member activity</h2></div><BarChart3 className="h-6 w-6 text-sidebar-primary" /></div>
          <div className="mt-7 flex h-36 items-end gap-2">
            {[54, 68, 48, 76, 88, 72, 64].map((height, index) => <div key={index} className="flex flex-1 flex-col items-center gap-2"><div className={`w-full rounded-t-lg ${index === 4 ? 'bg-sidebar-primary' : 'bg-sidebar-accent'}`} style={{ height: `${height}%` }} /><span className="mono-font text-[9px] text-sidebar-foreground/45">{['M', 'T', 'W', 'T', 'F', 'S', 'S'][index]}</span></div>)}
          </div>
          <div className="mt-6 border-t border-sidebar-foreground/10 pt-4"><div className="text-sm font-bold">{venue.dailyMembers} members visit on a typical day</div><p className="mt-1 text-xs leading-relaxed text-sidebar-foreground/55">{returningGuests} recent guests are already coming back for another meal.</p></div>
        </div>

        <div className="rounded-2xl border border-border bg-card p-5 shadow-sm sm:p-7">
          <div className="flex items-start justify-between gap-3"><div><p className="mono-font text-[10px] uppercase tracking-[.18em] text-accent">Recent members</p><h2 className="display-font mt-1 text-2xl font-bold tracking-[-.04em]">Latest visits</h2><p className="mt-1 text-xs text-muted-foreground">Your newest repeat-visit activity.</p></div><div className="rounded-xl bg-primary/20 p-2.5"><Users className="h-5 w-5" /></div></div>
          <div className="mt-5 divide-y divide-border">
            {ownerVisits.slice(0, 4).map((visit, index) => (
              <div key={visit.id} className={`flex items-center gap-3 py-4 first:pt-0 last:pb-0 ${index === 0 ? 'rounded-xl bg-primary/10 px-3' : ''}`}>
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-xs font-bold" style={{ backgroundColor: visit.color }}>{visit.initials}</div>
                <div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><span className="truncate text-sm font-bold">{visit.customer}</span>{visit.streak > 1 && <span className="rounded-full bg-accent/15 px-2 py-0.5 text-[9px] font-bold text-accent">Returning</span>}</div><div className="mt-1 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground"><span>{visit.date}</span><span>·</span><span>Day {visit.streak}</span></div></div>
                <div className="text-right"><div className="text-sm font-bold">{visit.amount}</div><div className="mt-1 flex items-center justify-end gap-1 text-[10px] text-accent"><BadgeCheck className="h-3 w-3" /> Verified</div></div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-5 flex flex-col gap-3 rounded-2xl border border-primary/30 bg-primary/10 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5">
        <div className="flex items-start gap-3"><Gift className="mt-0.5 h-5 w-5 shrink-0 text-accent" /><div><div className="text-sm font-bold">Your current streak offer is 15% off after 10 visits.</div><p className="mt-1 text-xs text-muted-foreground">Keep it visible in the restaurant listing so students know why it is worth returning.</p></div></div>
        <span className="shrink-0 rounded-xl bg-foreground px-3 py-2 text-[10px] font-bold text-background">{verifiedToday} visits today</span>
      </div>
    </div>
  );
}

function Home() {
  const [activeView, setActiveView] = useState<View>('home');
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);
  const [ownerAuthenticated, setOwnerAuthenticated] = useState(false);
  const [rewardClaimed, setRewardClaimed] = useState(false);
  const [visits] = useState<Visit[]>(startingVisits);
  const [ownerVisits] = useState<OwnerVisit[]>(startingOwnerVisits);
  const visitCount = 6;
  const navigate = (view: View) => { setActiveView(view); setSelectedRestaurant(null); };
  return <div className="app-shell app-noise flex"><AppSidebar active={activeView} onNavigate={navigate} /><div className="min-w-0 flex-1"><Topbar active={activeView} onNavigate={navigate} /><main className="mobile-bottom-safe">{activeView === 'home' && <HomeView onNavigate={navigate} onSelect={setSelectedRestaurant} visitCount={visitCount} />}{activeView === 'discover' && <DiscoverView onSelect={setSelectedRestaurant} />}{activeView === 'streak' && <StreakView visitCount={visitCount} onNavigate={navigate} />}{activeView === 'visits' && <VisitsView visits={visits} onNavigate={navigate} />}{activeView === 'profile' && <ProfileView onNavigate={navigate} rewardClaimed={rewardClaimed} onClaimReward={() => setRewardClaimed(true)} />}{activeView === 'owner' && (ownerAuthenticated ? <OwnerView ownerVisits={ownerVisits} onLogout={() => { setOwnerAuthenticated(false); setActiveView('home'); }} /> : <OwnerLogin onLogin={() => setOwnerAuthenticated(true)} />)}</main></div><MobileNav active={activeView} onNavigate={navigate} />{selectedRestaurant && <RestaurantDetail restaurant={selectedRestaurant} onClose={() => setSelectedRestaurant(null)} />}</div>;
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={Home} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;